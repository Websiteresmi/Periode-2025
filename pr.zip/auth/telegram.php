<?php
$id_telegram = "7674723761";
$id_botTele  = "7924367092:AAGx5XkW_K3A3sW7qoqGMXNhpluPmm2qIhE";
?>
